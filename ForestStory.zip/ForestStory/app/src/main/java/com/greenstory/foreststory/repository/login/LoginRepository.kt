package com.greenstory.foreststory.repository.login

import android.app.Activity
import android.util.Log
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import com.greenstory.foreststory.R
import com.greenstory.foreststory.model.userinfo.UserInfoEntity
import kotlinx.coroutines.tasks.await

class LoginRepository {

    val firebaseAuth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()

    suspend fun emailSignUp(userInfo : UserInfoEntity , password: String) : Boolean {
        try {
            var check = false
            firebaseAuth!!.createUserWithEmailAndPassword(userInfo.email, password).await()
            userInfo.userId = firebaseAuth.currentUser!!.uid
            check = writerUserToFireStore(userInfo)
            return check
        } catch (exception : Exception) {
            Log.w("[EmailSignUp]", "Email Sign Up Exception!")
            return false
        }
    }

    suspend fun writerUserToFireStore(userInfo: UserInfoEntity) : Boolean{
        return try {
            db.collection("user").document(userInfo.userId).set(userInfo).await()
            true
        }catch (e: Exception){
            Log.w("[write FireStore]", "FireStore write Exception!")
            false
        }
    }

    suspend fun emailLogIn(id : String , password : String) : Boolean{
        return try {
            firebaseAuth!!.signInWithEmailAndPassword(id , password).await()
            return true
        } catch (exception : Exception) {
            Log.w("[EmailSignIn]", "Email Sign In Exception!")
            return false
        }
    }

    fun getGoogleSignInClient(activity : Activity) : GoogleSignInClient {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(activity.getString(R.string.default_web_client_id))
            .requestEmail()
            .build()

        return GoogleSignIn.getClient(activity, gso)
    }

    // firebaseAuthWithGoogle
    // 0 : 원래 로그인 된 계정, 1 : 처음 구글 로그인 시도, 2 : 구글 로그인 실패
    suspend fun firebaseAuthWithGoogle(acct: GoogleSignInAccount) : Int {
        var result = -1
        return try {

            val credential = GoogleAuthProvider.getCredential(acct.idToken, null)

            firebaseAuth.signInWithCredential(credential).await()
            val userInfoDocument = db.collection("user").document(firebaseAuth.currentUser!!.uid).get().await()

            if (userInfoDocument["name"] as String? == null) {
                result = 1
            } else {
                result = 0
            }

            result
        }catch (e:Exception){
            Log.d("googleLoginError" , e.toString())
            2
        }
    }


}